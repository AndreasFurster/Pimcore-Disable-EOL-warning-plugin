try{
	localStorage.setItem('pimcore_eol_warning', true);
}
catch(error){
	console.log("Could not access localStorage");
}
