<?php


class DisableEolWarningPimcore2_IndexController extends Pimcore_Controller_Action_Admin {
    
    public function indexAction () {

        // reachable via http://your.domain/plugin/DisableEolWarningPimcore2/index/index

    }
}
